#!/system/bin/sh
MODDIR=${0%/*}

# Watchdog V14
BOOT_COUNT=$(getprop init.svc_debug.boot_count)
if [ "$BOOT_COUNT" -gt 2 ]; then
    touch $MODDIR/disable
    exit 0
fi

# [V14 NEW] SURFACEFLINGER ENHANCEMENT
# Menghilangkan delay vsync dan meningkatkan refresh rate stability
resetprop debug.sf.latch_unsignaled 1
resetprop debug.sf.disable_backpressure 1
resetprop debug.sf.hw 1
resetprop debug.cpurend.vsync false
resetprop ro.config.enable.hw_accel true

# Log Marker V14
echo "Magic Random Pro V14 (Aether) Active: $(date)" > /data/local/tmp/magic_random_v14.log
