#!/system/bin/sh
MODDIR=${0%/*}
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 15; done

# [V14 NEW] SQLITE VACUUM
# Membersihkan database aplikasi agar pembacaan data lebih cepat
for db in $(find /data -name "*.db"); do
    sqlite3 $db "VACUUM;" 2>/dev/null
done

# [V14 NEW] I/O SCHEDULER TUNING
# Mengatur antrian data agar aplikasi tidak 'Not Responding'
for queue in /sys/block/*/queue; do
    echo 0 > $queue/add_random
    echo 0 > $queue/iostats
    echo 1 > $queue/nomerges
    echo 256 > $queue/read_ahead_kb
done

# [V13 LEGACY] ZRAM LZ4 & GMS DOZE
if grep -q lz4 /sys/block/zram0/comp_algorithm; then
  echo lz4 > /sys/block/zram0/comp_algorithm
fi
echo 60 > /proc/sys/vm/swappiness
cmd appops set com.google.android.gms RUN_IN_BACKGROUND ignore 2>/dev/null

# AI Neural Logic 9.0 - Aether Scaling
while true; do
  LOAD=$(uptime | awk '{print $10}' | cut -d. -f1)
  
  if [ "$LOAD" -gt 4 ]; then
    # High Performance Mode
    echo "performance" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
    echo 0 > /proc/sys/vm/swappiness
    echo 20 > /proc/sys/vm/vfs_cache_pressure
  else
    # Balance / Daily Mode
    echo "schedutil" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
    echo 60 > /proc/sys/vm/swappiness
    echo 100 > /proc/sys/vm/vfs_cache_pressure
  fi
  
  # Memaksa FSTRIM secara berkala jika idle
  if [ "$LOAD" -lt 1 ]; then
    fstrim -v /data
    sleep 300
  fi
  sleep 60
done &
