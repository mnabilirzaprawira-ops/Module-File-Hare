#!/system/bin/sh
# Eksekusi instant saat tombol ditekan dari Magisk / KSU
MODPATH="/data/adb/modules/magic_random_pro"
sh $MODPATH/common/functions.sh boost
