#!/system/bin/sh

# Fungsi Delay Anti-Error
wait_sec() {
  /system/bin/sleep "$1" 2>/dev/null || true
}

ui_print " "
ui_print "==========================================="
ui_print "   MAGIC RANDOM PRO V17 | RAIDEN EI        "
ui_print "      [ COLUMBINA CRYO X ETERNITY ]        "
ui_print "==========================================="
ui_print " "

ui_print "--- [ HALL OF FAME: ANDROID LEGENDS ] ---"
ui_print " "
ui_print " 👑 JesusFreke, Cyanogen, TopJohnWu"
ui_print " "
ui_print "-------------------------------------------"
ui_print "   DEVELOPED BY: Nabil Irza Prawira        "
ui_print "   TELEGRAM    : @n4bilirz                 "
ui_print "-------------------------------------------"
wait_sec 2

ui_print " "
ui_print " > Inazuma shines eternal! Memulai instalasi..."
ui_print " "

ui_print " [1/8] Menghancurkan Batas Sistem..."
wait_sec 1
ui_print "       Status: [MUSOU ISSHIN DRAWN]"
ui_print " "

ui_print " [2/8] Menyelaraskan Elemen Electro x Cryo..."
wait_sec 1
ui_print "       Resonance: [ETERNITY ZERO]"
ui_print " "

ui_print " [3/8] Menyuntikkan Eternity Logic 10.0..."
wait_sec 1
ui_print "       AI: [ACTIVE & OVERCLOCKED]"
ui_print " "

ui_print " [4/8] Membuka Segel ART Compiler..."
wait_sec 1
ui_print "       Dalvik: [SPEED-PROFILE FORCED]"
ui_print " "

ui_print " [5/8] Menyiapkan UI Glassmorphism V17..."
wait_sec 1
ui_print "       WebUI: [STANDBY]"
ui_print " "

ui_print " [6/8] Spoofing Identity (Pixel 9 Pro XL)..."
wait_sec 1
ui_print "       Security: [ILLUSION CASTED]"
ui_print " "

ui_print " [7/8] Cryo-Vacuum SQLite Databases..."
wait_sec 2
ui_print "       Storage: [DEFRAGMENTED]"
ui_print " "

ui_print " [8/8] Mengunci Keabadian Sistem..."
wait_sec 1
ui_print " "

ui_print "==========================================="
ui_print "   INSTALASI V17 RAIDEN EI SELESAI!        "
ui_print "   Buka KSU/APatch untuk akses Dashboard.  "
ui_print "==========================================="
wait_sec 1

# --- PERMISSIONS ---
ui_print " "
ui_print "- Menyetel Izin Sistem (CHMOD)..."
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755
