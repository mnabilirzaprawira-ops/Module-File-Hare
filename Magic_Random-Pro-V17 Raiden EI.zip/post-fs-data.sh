#!/system/bin/sh
MODDIR=${0%/*}

# Watchdog V17
BOOT_COUNT=$(getprop init.svc_debug.boot_count)
if [ "$BOOT_COUNT" -gt 2 ]; then
    touch $MODDIR/disable
    exit 0
fi

# [V17] SURFACEFLINGER ETERNITY ENHANCEMENT
resetprop debug.sf.latch_unsignaled 1
resetprop debug.sf.disable_backpressure 1
resetprop debug.sf.hw 1
resetprop debug.cpurend.vsync false
resetprop ro.config.enable.hw_accel true
resetprop debug.sf.showupdates 0

# Log Marker V17
echo "Magic Random Pro V17 (Raiden x Columbina) Active: $(date)" > /data/local/tmp/mrp_v17_eternity.log
