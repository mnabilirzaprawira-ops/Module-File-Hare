#!/system/bin/sh
MODDIR=${0%/*}
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 15; done

# [V17] MUSOU SQLITE VACUUM
# Membersihkan database aplikasi secara agresif untuk I/O instan
for db in $(find /data -name "*.db" 2>/dev/null | head -n 50); do
    sqlite3 $db "VACUUM;" 2>/dev/null
done

# [V17] ELECTRO-CRYO I/O SCHEDULER TUNING
for queue in /sys/block/*/queue; do
    echo 0 > $queue/add_random
    echo 0 > $queue/iostats
    echo 1 > $queue/nomerges
    echo 512 > $queue/read_ahead_kb
done

# [ZRAM & MEMORY PURGE]
if grep -q lz4 /sys/block/zram0/comp_algorithm; then
  echo lz4 > /sys/block/zram0/comp_algorithm
fi
echo 40 > /proc/sys/vm/swappiness
echo 10 > /proc/sys/vm/stat_interval

# AI Neural Logic 10.0 - Eternity Scaling
while true; do
  LOAD=$(uptime | awk '{print $10}' | cut -d. -f1)
  
  if [ "$LOAD" -gt 4 ]; then
    # Mode Tempur (Musou Isshin)
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        echo "performance" > $cpu 2>/dev/null
    done
    echo 0 > /proc/sys/vm/swappiness
    echo 20 > /proc/sys/vm/vfs_cache_pressure
  else
    # Mode Pasif (Columbina Cryo Sleep)
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        echo "schedutil" > $cpu 2>/dev/null
    done
    echo 40 > /proc/sys/vm/swappiness
    echo 100 > /proc/sys/vm/vfs_cache_pressure
  fi
  
  if [ "$LOAD" -lt 1 ]; then
    fstrim -v /data > /dev/null 2>&1
    sleep 300
  fi
  sleep 60
done &
