ui_print "======================================"
ui_print "      MAGIC RANDOM PRO V8      "
ui_print "      The Smartest Mod by @n4bilirz   "
ui_print "======================================"
ui_print "- AI Smart-Logic 2.0: [READY]"
ui_print "- Network Latency Fix: [INJECTED]"
ui_print "- RAM Turbo Boost:     [ACTIVE]"
ui_print "- Boot Guard V2:       [ENFORCED]"
ui_print "--------------------------------------"
ui_print " STATUS: 30% Faster & More Stable!    "
ui_print "======================================"

set_perm_recursive $MODPATH 0 0 0755 0644
