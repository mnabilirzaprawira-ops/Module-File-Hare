#!/system/bin/sh

# Fungsi Delay yang AMAN (Anti-Error)
# Kita coba panggil sleep sistem, kalau gagal ya lanjut aja (biar ga error code 1)
wait_sec() {
  /system/bin/sleep "$1" 2>/dev/null || true
}

# --- HEADER OPENING ---
ui_print " "
ui_print "==========================================="
ui_print "       MAGIC RANDOM PRO V11 | APEX         "
ui_print "==========================================="
ui_print " "

# --- HALL OF FAME TRIBUTE ---
ui_print "--- [ HALL OF FAME: ANDROID LEGENDS ] ---"
ui_print " "
ui_print "Respect to those who paved the way:"
wait_sec 1
ui_print " 👑 JesusFreke   : The First Root (2008)"
wait_sec 1
ui_print " 👑 Cyanogen     : The Father of Custom ROM"
wait_sec 1
ui_print " 👑 Chainfire    : The SuperSU Legend"
wait_sec 1
ui_print " 👑 TeamWin      : The TWRP Recovery Gods"
wait_sec 1
ui_print " 👑 TopJohnWu    : The Creator of Magisk"
wait_sec 1
ui_print " "
ui_print "-------------------------------------------"
ui_print "   LEGACY CONTINUED BY: @n4bilirz (2025)   "
ui_print "-------------------------------------------"
wait_sec 2

# --- INSTALASI DIMULAI ---
ui_print " "
ui_print " > Memulai Instalasi V11 Elite..."
ui_print " "
ui_print " [1/5] Injecting AI Neural Logic 6.0..."
wait_sec 1
ui_print "       Status: [ACTIVE]"
ui_print " "
ui_print " [2/5] Fixing UI Stutter & Lag..."
wait_sec 1
ui_print "       Frame Pacing: [SMOOTH 144Hz]"
ui_print " "
ui_print " [3/5] Activating Smart Battery Gen-2..."
ui_print "       Deep Sleep: [OPTIMIZED]"
ui_print " "
ui_print " [4/5] Spoofing Device Identity..."
ui_print "       Target: [Google Pixel 9 Pro]"
ui_print " "
ui_print " [5/5] Finalizing System..."
wait_sec 1
ui_print "       Wi-Fi Stability: [LOCKED]"
ui_print "       SafetyNet Watchdog: [ON]"

# --- PENUTUP ---
ui_print " "
ui_print "==========================================="
ui_print "    INSTALASI SUKSES / INSTALL SUCCESS     "
ui_print "    REBOOT HP ANDA SEKARANG / REBOOT NOW   "
ui_print "==========================================="
ui_print "    Support: @n4bilirz | 150K Community    "
ui_print "==========================================="

# PERMISSIONS
set_perm_recursive $MODPATH 0 0 0755 0644
