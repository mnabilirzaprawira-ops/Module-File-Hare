#!/system/bin/sh
MODDIR=${0%/*}

# Watchdog: Jika ponsel gagal boot 2 kali, nonaktifkan semua tweak modul ini
BOOT_COUNT=$(getprop init.svc_debug.boot_count)
if [ "$BOOT_COUNT" -gt 2 ]; then
    touch $MODDIR/disable
    exit 0
fi
