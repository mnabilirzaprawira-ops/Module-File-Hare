#!/system/bin/sh
MODDIR=${0%/*}
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 15; done

# [V14] I/O SCHEDULER TUNING & FSTRIM
fstrim -v /data
fstrim -v /cache
for queue in /sys/block/*/queue; do
    echo 0 > $queue/add_random
    echo 1 > $queue/nomerges
    echo 256 > $queue/read_ahead_kb
done

# [V13] ZRAM LZ4 & SWAPPINESS
if grep -q lz4 /sys/block/zram0/comp_algorithm; then
  echo lz4 > /sys/block/zram0/comp_algorithm
fi
echo 60 > /proc/sys/vm/swappiness

# [V10] AI NEURAL LOGIC 9.0 (Dynamic Governor)
while true; do
  LOAD=$(uptime | awk '{print $10}' | cut -d. -f1)
  if [ "$LOAD" -gt 4 ]; then
    echo "performance" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
  else
    echo "schedutil" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
  fi
  sleep 45 
done &
