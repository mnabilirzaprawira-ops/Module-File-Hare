#!/system/bin/sh
MODDIR=${0%/*}

# Watchdog Protection
BOOT_COUNT=$(getprop init.svc_debug.boot_count)
if [ "$BOOT_COUNT" -gt 2 ]; then
    touch $MODDIR/disable
    exit 0
fi

# [V14] SURFACEFLINGER STABILIZER
resetprop debug.sf.latch_unsignaled 1
resetprop debug.sf.disable_backpressure 1
resetprop debug.cpurend.vsync false
