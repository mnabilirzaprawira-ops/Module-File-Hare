#!/system/bin/sh
MODDIR=${0%/*}
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 15; done

# [V16 CRYO] FSTRIM ON BOOT
fstrim -v /data
fstrim -v /cache

# AI Neural Logic V16 - Cryo Loop
while true; do
  LOAD=$(uptime | awk '{print $10}' | cut -d. -f1)
  
  # Jika Load sangat tinggi (Gaming Berat)
  if [ "$LOAD" -gt 4 ]; then
    echo "performance" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
    echo 0 > /proc/sys/vm/swappiness # Matikan ZRAM biar CPU fokus ke game
  else
    echo "schedutil" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
    echo 60 > /proc/sys/vm/swappiness # Nyalakan ZRAM buat Multitasking
  fi

  # Cryo Heartbeat Marker
  echo "MRP_V16_CRYO: [ACTIVE] | $(date)" > /data/local/tmp/mrp_v16_cryo.log
  
  sleep 45 
done &
