#!/system/bin/sh
MODDIR=${0%/*}

# Watchdog: Jika ponsel gagal boot 2 kali, nonaktifkan semua tweak modul ini
BOOT_COUNT=$(getprop init.svc_debug.boot_count)
if [ "$BOOT_COUNT" -gt 2 ]; then
    touch $MODDIR/disable
    exit 0
fi

# [V12] Log Marker
# Menandakan script berjalan sukses di background
echo "Magic Random Pro V12 Active: $(date)" > /data/local/tmp/magic_random_v12.log
chmod 644 /data/local/tmp/magic_random_v12.log
