#!/system/bin/sh
MODDIR=${0%/*}
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 15; done

# [V12 NEW] FSTRIM ON BOOT
# Membersihkan sampah blok data agar Storage kencang (Anti-Lag I/O)
fstrim -v /data
fstrim -v /cache

# AI Neural Logic 7.0 - Titanium Scaling
while true; do
  # Ambil Load Average (Beban CPU)
  LOAD=$(uptime | awk '{print $10}' | cut -d. -f1)
  
  # [LOGIC 1] Dynamic Governor
  # Jika beban > 3 (Gaming/Render), paksa Performance
  if [ "$LOAD" -gt 3 ]; then
    echo "performance" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
    # [V12] Matikan ZRAM saat gaming berat agar CPU fokus
    echo 0 > /proc/sys/vm/swappiness
  else
    echo "schedutil" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
    # [V12] Kembalikan ZRAM saat santai untuk multitasking
    echo 60 > /proc/sys/vm/swappiness
  fi

  # [LOGIC 2] Smart RAM Management (Pengganti drop_caches kasar V11)
  # Daripada menghapus cache (yang bikin boros batre reload app), 
  # kita atur seberapa agresif Android membuang memori.
  
  if [ "$LOAD" -lt 1 ]; then
    # Mode Idle/Deep Sleep: Hemat RAM
    echo 100 > /proc/sys/vm/vfs_cache_pressure
    sleep 120
  else
    # Mode Aktif: Pertahankan Cache agar buka aplikasi Cepat
    echo 50 > /proc/sys/vm/vfs_cache_pressure
    sleep 45
  fi
done &
