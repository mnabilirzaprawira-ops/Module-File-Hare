#!/system/bin/sh
# =======================================================================
# CUSTOMIZE.SH - MRP V16 COLUMBIA CRYO (ABSOLUTE ZERO)
# DEV: Nabil Irza Prawira (@n4bilirz)
# =======================================================================

# Fungsi Delay Anti-Error (Sangat aman buat KSU Next & APatch)
wait_sec() {
  /system/bin/sleep "$1" 2>/dev/null || true
}

ui_print " "
ui_print "==========================================="
ui_print "   MAGIC RANDOM PRO V16 | COLUMBIA CRYO    "
ui_print "       [ ABSOLUTE ZERO EDITION ]           "
ui_print "==========================================="
ui_print " "

# --- HALL OF FAME ---
ui_print "--- [ HALL OF FAME: ANDROID LEGENDS ] ---"
ui_print " "
ui_print "Respect to those who paved the way:"
wait_sec 1
ui_print " 👑 JesusFreke   : The First Root (G1)"
wait_sec 1
ui_print " 👑 Cyanogen     : Father of Custom ROM"
wait_sec 1
ui_print " 👑 Chainfire    : The SuperSU Legend"
wait_sec 1
ui_print " 👑 TeamWin      : TWRP Recovery Gods"
wait_sec 1
ui_print " 👑 TopJohnWu    : The Creator of Magisk"
wait_sec 1
ui_print " "
ui_print "-------------------------------------------"
ui_print "   LEAD MODDER : Nabil Irza Prawira        "
ui_print "   ALIAS       : @n4bilirz                 "
ui_print "   THEME       : Delusion Hydro B5 Sync    "
ui_print "-------------------------------------------"
wait_sec 2

# --- PROSES INSTALASI ---
ui_print " "
ui_print " > Menginisiasi Protokol Columbia..."
wait_sec 1
ui_print " "

ui_print " [1/7] Injecting Absolute Zero Engine..."
wait_sec 1
ui_print "       Status: [FROZEN SOLID]"
ui_print " "

ui_print " [2/7] Syncing Delusion Hydro Catalyst..."
wait_sec 1
ui_print "       Resonance: [LUNAR-CHARGED]"
ui_print " "

ui_print " [3/7] Freezing Memory Allocation..."
wait_sec 1
ui_print "       RAM State: [CRYO-COMPACTED]"
ui_print " "

ui_print " [4/7] Overriding Thermal Limits..."
wait_sec 1
ui_print "       Warning: [FATUI OVERCLOCK ACTIVE]"
ui_print " "

ui_print " [5/7] Deploying Liquid Glass WebUI..."
wait_sec 1
ui_print "       Interface: [HYDRO HARMONIC]"
ui_print " "

ui_print " [6/7] Spoofing Device Identity..."
wait_sec 1
ui_print "       Target: [Pixel 9 Pro XL - Cryo]"
ui_print " "

ui_print " [7/7] Finalizing Crystal I/O Vacuum..."
wait_sec 2
ui_print "       Database: [LUNAR-CRYSTALLIZE]"
ui_print " "

ui_print "==========================================="
ui_print "   INSTALASI V16 ABSOLUTE ZERO SELESAI!    "
ui_print "   Buka KSU/APatch untuk akses Dashboard.  "
ui_print "==========================================="
wait_sec 1

# --- PERMISSIONS (SANGAT PENTING UNTUK WEBUI) ---
ui_print " "
ui_print "- Menyetel Izin Sistem (CHMOD 755)..."

# Setel izin standar folder dan file
set_perm_recursive $MODPATH 0 0 0755 0644

# Paksa izin Execute (Eksekusi) khusus untuk file shell agar WebUI tidak Error
set_perm $MODPATH/action.sh 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755
set_perm $MODPATH/common/functions.sh 0 0 0755

wait_sec 1
ui_print "- Izin Berhasil Disetel! Sistem Aman."
ui_print " "
