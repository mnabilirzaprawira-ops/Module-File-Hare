#!/system/bin/sh
wait_sec() {
  /system/bin/sleep "$1" 2>/dev/null || true
}

ui_print "==========================================="
ui_print "    MAGIC RANDOM PRO V15 | SINGULARITY     "
ui_print "         [ WEB-UI DASHBOARD EDITION ]      "
ui_print "==========================================="
ui_print " "
ui_print "--- [ HALL OF FAME: ANDROID LEGENDS ] ---"
ui_print " "
ui_print "Respect to those who paved the way:"
wait_sec 1
ui_print " 👑 JesusFreke, Cyanogen, TeamWin, TopJohnWu"
ui_print " "
ui_print "-------------------------------------------"
ui_print "   DEVELOPED BY: @n4bilirz (2026)          "
ui_print "-------------------------------------------"
wait_sec 1

ui_print " "
ui_print " > Memulai Instalasi V15 Singularity..."
ui_print " "
ui_print " [1/5] Injecting Singularity WebUI..."
ui_print " [2/5] Merging V8-V14 Legacy Code..."
ui_print " [3/5] Applying Hardware Acceleration..."
ui_print " [4/5] Tuning Quantum Network..."
ui_print " [5/5] Spoofing Pixel 10 Pro Identity..."
ui_print " "
ui_print "==========================================="
ui_print "  INSTALASI SUKSES! BUKA KERNELSU MANAGER  "
ui_print "  UNTUK MENGAKSES DASHBOARD MODULE INI!    "
ui_print "==========================================="

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/action.sh 0 0 0755
set_perm $MODPATH/common/functions.sh 0 0 0755
