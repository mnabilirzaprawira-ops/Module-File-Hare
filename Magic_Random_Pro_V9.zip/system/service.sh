#!/system/bin/sh
MODDIR=${0%/*}

while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 15; done

# AI Smart-Logic 3.0: High Frequency Monitoring
while true; do
  TEMP=$(cat /sys/class/thermal/thermal_zone0/temp | cut -c1-2)
  LOAD=$(uptime | awk '{print $10}' | cut -d. -f1)

  # Thermal Guard: Jika suhu > 45°C, turunkan performa agar tidak overheat
  if [ "$TEMP" -gt 45 ]; then
    echo "schedutil" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
    echo "60" > /sys/devices/system/cpu/cpufreq/interactive/target_loads
  # Performance Mode: Jika beban tinggi & suhu aman
  elif [ "$LOAD" -gt 2 ]; then
    echo "performance" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
    echo "1" > /proc/sys/kernel/sched_child_runs_first
  fi

  # Auto-Optimization Storage
  sync; echo 1 > /proc/sys/vm/compact_memory
  
  sleep 30 # 30% lebih responsif dari V7
done &
