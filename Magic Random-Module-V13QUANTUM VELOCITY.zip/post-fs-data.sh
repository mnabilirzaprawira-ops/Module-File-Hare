#!/system/bin/sh
MODDIR=${0%/*}

# Watchdog Protection
BOOT_COUNT=$(getprop init.svc_debug.boot_count)
if [ "$BOOT_COUNT" -gt 2 ]; then
    touch $MODDIR/disable
    exit 0
fi

# [V13] Log Marker
echo "Magic Random Pro V13 (Quantum) Active: $(date)" > /data/local/tmp/magic_random_v13.log
chmod 644 /data/local/tmp/magic_random_v13.log
