#!/system/bin/sh
MODDIR=${0%/*}
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 15; done

# [V12 LEGACY] FSTRIM ON BOOT
fstrim -v /data
fstrim -v /cache

# [V13 NEW] ZRAM OPTIMIZER (LZ4 / ZSTD)
# Cek apakah kernel support LZ4, kalau ada pakai, biar RAM kenceng
if grep -q lz4 /sys/block/zram0/comp_algorithm; then
  echo lz4 > /sys/block/zram0/comp_algorithm
elif grep -q zstd /sys/block/zram0/comp_algorithm; then
  echo zstd > /sys/block/zram0/comp_algorithm
fi
# Set swappiness balance
echo 60 > /proc/sys/vm/swappiness

# [V13 NEW] GMS DOZE (BATTERY SAVER)
# Mengurangi wakelock dari Google Play Services
pm enable com.google.android.gms/.chimera.GmsIntentOperationService 2>/dev/null
cmd appops set com.google.android.gms RUN_IN_BACKGROUND ignore 2>/dev/null

# AI Neural Logic 8.0 - Quantum Scaling
while true; do
  LOAD=$(uptime | awk '{print $10}' | cut -d. -f1)
  
  # [LOGIC 1] Dynamic Governor (V12 Improved)
  if [ "$LOAD" -gt 4 ]; then
    # Mode Gaming Berat / Rendering
    echo "performance" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
    # Matikan ZRAM saat gaming berat agar CPU pure performa
    echo 0 > /proc/sys/vm/swappiness
  else
    # Mode Harian
    echo "schedutil" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
    # Hidupkan ZRAM untuk multitasking
    echo 60 > /proc/sys/vm/swappiness
  fi

  # [LOGIC 2] Smart RAM Management (V12 Legacy)
  if [ "$LOAD" -lt 1 ]; then
    echo 100 > /proc/sys/vm/vfs_cache_pressure
    sleep 120
  else
    echo 50 > /proc/sys/vm/vfs_cache_pressure
    sleep 45
  fi
done &
